﻿namespace Xaminals.Controls
{
    public partial class FlyoutFooter : ContentView
    {
        public FlyoutFooter()
        {
            InitializeComponent();
        }
    }
}
