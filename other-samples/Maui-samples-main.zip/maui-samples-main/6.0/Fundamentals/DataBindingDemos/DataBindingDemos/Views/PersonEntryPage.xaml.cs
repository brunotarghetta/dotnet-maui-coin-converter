﻿namespace DataBindingDemos
{
    public partial class PersonEntryPage : ContentPage
    {
        public PersonEntryPage()
        {
            InitializeComponent();
        }
    }
}