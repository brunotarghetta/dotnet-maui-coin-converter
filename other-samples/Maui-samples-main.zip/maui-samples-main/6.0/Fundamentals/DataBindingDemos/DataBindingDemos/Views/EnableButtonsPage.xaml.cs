﻿namespace DataBindingDemos
{
    public partial class EnableButtonsPage : ContentPage
    {
        public EnableButtonsPage()
        {
            InitializeComponent();
        }
    }
}