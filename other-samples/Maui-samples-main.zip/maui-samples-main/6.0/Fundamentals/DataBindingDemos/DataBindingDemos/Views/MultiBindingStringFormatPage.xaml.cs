﻿namespace DataBindingDemos
{
    public partial class MultiBindingStringFormatPage : ContentPage
    {
        public MultiBindingStringFormatPage()
        {
            InitializeComponent();
        }
    }
}
