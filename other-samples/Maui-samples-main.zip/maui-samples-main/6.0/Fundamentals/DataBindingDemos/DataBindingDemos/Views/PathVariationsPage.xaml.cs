﻿namespace DataBindingDemos
{
    public partial class PathVariationsPage : ContentPage
    {
        public PathVariationsPage()
        {
            InitializeComponent();
        }
    }
}