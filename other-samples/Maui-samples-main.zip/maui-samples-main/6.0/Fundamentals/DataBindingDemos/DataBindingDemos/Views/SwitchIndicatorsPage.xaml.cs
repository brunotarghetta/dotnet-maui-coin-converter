﻿namespace DataBindingDemos
{
    public partial class SwitchIndicatorsPage : ContentPage
    {
        public SwitchIndicatorsPage()
        {
            InitializeComponent();
        }
    }
}