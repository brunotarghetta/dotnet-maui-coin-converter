﻿namespace DataBindingDemos
{
    public partial class MultiBindingConverterPage : ContentPage
    {
        public MultiBindingConverterPage()
        {
            InitializeComponent();
        }
    }
}
