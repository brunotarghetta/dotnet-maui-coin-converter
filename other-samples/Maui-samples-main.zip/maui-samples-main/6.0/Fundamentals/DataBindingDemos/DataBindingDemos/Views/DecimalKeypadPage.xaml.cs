﻿namespace DataBindingDemos
{
    public partial class DecimalKeypadPage : ContentPage
    {
        public DecimalKeypadPage()
        {
            InitializeComponent();
        }
    }
}