﻿namespace DataBindingDemos
{
    public partial class BindingContextInheritancePage : ContentPage
    {
        public BindingContextInheritancePage()
        {
            InitializeComponent();
        }
    }
}