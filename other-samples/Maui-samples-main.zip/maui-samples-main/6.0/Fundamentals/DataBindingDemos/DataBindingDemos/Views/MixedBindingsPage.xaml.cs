﻿namespace DataBindingDemos
{
    public partial class MixedBindingsPage : ContentPage
    {
        public MixedBindingsPage()
        {
            InitializeComponent();
        }
    }
}
