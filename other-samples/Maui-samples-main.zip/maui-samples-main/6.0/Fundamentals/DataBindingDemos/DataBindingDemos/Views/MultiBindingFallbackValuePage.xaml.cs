﻿namespace DataBindingDemos
{
    public partial class MultiBindingFallbackValuePage : ContentPage
    {
        public MultiBindingFallbackValuePage()
        {
            InitializeComponent();
        }
    }
}
