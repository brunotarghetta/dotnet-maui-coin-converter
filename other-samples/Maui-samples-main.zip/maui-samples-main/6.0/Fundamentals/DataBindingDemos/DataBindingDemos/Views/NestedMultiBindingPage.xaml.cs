﻿namespace DataBindingDemos
{
    public partial class NestedMultiBindingPage : ContentPage
    {
        public NestedMultiBindingPage()
        {
            InitializeComponent();
        }
    }
}
