﻿namespace DataBindingDemos
{
    public partial class RelativeSourceTemplatedParentPage : ContentPage
    {
        public RelativeSourceTemplatedParentPage()
        {
            InitializeComponent();
        }
    }
}
