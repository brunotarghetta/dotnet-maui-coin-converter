﻿namespace ControlTemplateDemos
{
    public partial class ReplaceTemplateCardViewPage : ContentPage
    {
        public ReplaceTemplateCardViewPage()
        {
            InitializeComponent();
        }
    }
}
