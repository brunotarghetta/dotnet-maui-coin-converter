﻿namespace ControlTemplateDemos
{
    public partial class RelativeSourceBindingCardViewPage : ContentPage
    {
        public RelativeSourceBindingCardViewPage()
        {
            InitializeComponent();
        }
    }
}
