﻿namespace ControlTemplateDemos
{
    public partial class BindToViewModelPage : ContentPage
    {
        public BindToViewModelPage()
        {
            InitializeComponent();
        }
    }
}
