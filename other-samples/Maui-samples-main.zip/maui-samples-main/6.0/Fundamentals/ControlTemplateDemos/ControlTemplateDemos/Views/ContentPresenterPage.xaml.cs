﻿using ControlTemplateDemos.Controls;

namespace ControlTemplateDemos
{
    public partial class ContentPresenterPage : HeaderFooterPage
    {
        public ContentPresenterPage()
        {
            InitializeComponent();
        }
    }
}
