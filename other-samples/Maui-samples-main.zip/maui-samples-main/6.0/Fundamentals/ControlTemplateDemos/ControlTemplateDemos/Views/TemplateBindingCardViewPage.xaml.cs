﻿namespace ControlTemplateDemos
{
    public partial class TemplateBindingCardViewPage : ContentPage
    {
        public TemplateBindingCardViewPage()
        {
            InitializeComponent();
        }
    }
}
