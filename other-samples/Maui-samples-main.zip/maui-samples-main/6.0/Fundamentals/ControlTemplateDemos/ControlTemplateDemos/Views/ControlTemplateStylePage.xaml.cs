﻿namespace ControlTemplateDemos
{
    public partial class ControlTemplateStylePage : ContentPage
    {
        public ControlTemplateStylePage()
        {
            InitializeComponent();
        }
    }
}
