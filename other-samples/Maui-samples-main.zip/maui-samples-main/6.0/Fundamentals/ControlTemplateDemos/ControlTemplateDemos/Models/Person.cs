﻿namespace ControlTemplateDemos
{
    public class Person
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
