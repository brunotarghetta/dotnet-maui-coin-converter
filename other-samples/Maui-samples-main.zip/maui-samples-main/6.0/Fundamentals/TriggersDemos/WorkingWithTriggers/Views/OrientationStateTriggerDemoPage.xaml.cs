﻿namespace WorkingWithTriggers
{
    public partial class OrientationStateTriggerDemoPage : ContentPage
    {
        public OrientationStateTriggerDemoPage()
        {
            InitializeComponent();
        }
    }
}
