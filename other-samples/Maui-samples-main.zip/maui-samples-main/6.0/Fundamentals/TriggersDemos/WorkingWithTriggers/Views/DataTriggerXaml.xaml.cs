﻿namespace WorkingWithTriggers
{
	public partial class DataTriggerXaml : ContentPage
	{
		public DataTriggerXaml ()
		{
			InitializeComponent ();
		}
	}
}

