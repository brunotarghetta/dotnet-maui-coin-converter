﻿namespace WorkingWithTriggers
{
    public partial class AdaptiveTriggerDemoPage : ContentPage
    {
        public AdaptiveTriggerDemoPage()
        {
            InitializeComponent();
        }
    }
}
