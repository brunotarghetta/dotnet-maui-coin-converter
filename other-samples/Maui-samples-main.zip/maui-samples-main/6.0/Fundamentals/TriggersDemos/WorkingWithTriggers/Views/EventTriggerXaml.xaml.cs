﻿namespace WorkingWithTriggers
{
	public partial class EventTriggerXaml : ContentPage
	{
		public EventTriggerXaml ()
		{
			InitializeComponent ();
		}
	}
}

