﻿namespace WorkingWithTriggers
{
    public partial class DeviceStateTriggerDemoPage : ContentPage
    {
        public DeviceStateTriggerDemoPage()
        {
            InitializeComponent();
        }
    }
}
