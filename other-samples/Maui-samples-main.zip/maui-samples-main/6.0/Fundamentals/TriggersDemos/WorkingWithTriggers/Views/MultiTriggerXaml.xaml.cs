﻿namespace WorkingWithTriggers
{
	public partial class MultiTriggerXaml : ContentPage
	{
		public MultiTriggerXaml ()
		{
			InitializeComponent ();
		}
	}
}

