﻿namespace WorkingWithTriggers
{
	public partial class PropertyTriggerXaml : ContentPage
	{
		public PropertyTriggerXaml ()
		{
			InitializeComponent ();
		}
	}
}

