﻿namespace WorkingWithTriggers
{
    public partial class CompareStateTriggerDemoPage : ContentPage
    {
        public CompareStateTriggerDemoPage()
        {
            InitializeComponent();
        }
    }
}
