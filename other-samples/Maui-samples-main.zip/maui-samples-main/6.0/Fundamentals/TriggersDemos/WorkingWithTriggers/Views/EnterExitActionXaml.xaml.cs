﻿namespace WorkingWithTriggers
{
	public partial class EnterExitActionXaml : ContentPage
	{
		public EnterExitActionXaml ()
		{
			InitializeComponent ();
		}
	}
}

