﻿namespace DataTemplates
{
    public partial class PersonView : ContentView
    {
        public PersonView()
        {
            InitializeComponent();
        }
    }
}
