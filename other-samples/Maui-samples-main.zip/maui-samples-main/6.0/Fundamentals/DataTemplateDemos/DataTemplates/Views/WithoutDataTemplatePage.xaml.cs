﻿namespace DataTemplates
{
    public partial class WithoutDataTemplatePage : ContentPage
    {
        public WithoutDataTemplatePage()
        {
            InitializeComponent();
        }
    }
}

