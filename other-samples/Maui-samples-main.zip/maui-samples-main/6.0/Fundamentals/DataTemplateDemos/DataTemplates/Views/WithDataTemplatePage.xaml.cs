﻿namespace DataTemplates
{
    public partial class WithDataTemplatePage : ContentPage
    {
        public WithDataTemplatePage()
        {
            InitializeComponent();
        }
    }
}

