﻿namespace DataTemplates
{
    public partial class WithDataTemplatePageFromType : ContentPage
    {
        public WithDataTemplatePageFromType()
        {
            InitializeComponent();
        }
    }
}
