﻿namespace BehaviorsDemos
{
	public partial class AttachedNumericValidationPage : ContentPage
	{
		public AttachedNumericValidationPage ()
		{
			InitializeComponent ();
		}
	}
}

