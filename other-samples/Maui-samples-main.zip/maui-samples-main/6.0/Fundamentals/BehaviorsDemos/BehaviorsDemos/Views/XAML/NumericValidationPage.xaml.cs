﻿namespace BehaviorsDemos
{
	public partial class NumericValidationPage : ContentPage
	{
		public NumericValidationPage ()
		{
			InitializeComponent ();
		}
	}
}

