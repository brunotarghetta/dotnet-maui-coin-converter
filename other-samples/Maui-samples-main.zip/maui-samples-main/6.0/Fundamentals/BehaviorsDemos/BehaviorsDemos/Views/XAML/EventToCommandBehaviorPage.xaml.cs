﻿namespace BehaviorsDemos
{
	public partial class EventToCommandBehaviorPage : ContentPage
	{
		public EventToCommandBehaviorPage ()
		{
            InitializeComponent ();
		}
	}
}

