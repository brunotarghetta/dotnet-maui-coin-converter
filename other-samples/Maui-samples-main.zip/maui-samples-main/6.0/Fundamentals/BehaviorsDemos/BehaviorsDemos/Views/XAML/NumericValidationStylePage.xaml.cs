﻿namespace BehaviorsDemos
{
	public partial class NumericValidationStylePage : ContentPage
	{
		public NumericValidationStylePage ()
		{
			InitializeComponent ();
		}
	}
}

