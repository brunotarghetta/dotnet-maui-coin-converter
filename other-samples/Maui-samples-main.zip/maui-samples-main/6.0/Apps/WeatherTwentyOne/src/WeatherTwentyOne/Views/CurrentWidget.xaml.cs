﻿namespace WeatherTwentyOne.Views;

public partial class CurrentWidget
{
    public CurrentWidget()
    {
        InitializeComponent();
    }
}
