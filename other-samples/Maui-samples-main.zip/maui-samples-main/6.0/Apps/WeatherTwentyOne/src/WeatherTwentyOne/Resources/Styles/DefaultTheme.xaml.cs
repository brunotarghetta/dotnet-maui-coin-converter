﻿namespace WeatherTwentyOne.Resources.Styles;

public partial class DefaultTheme : ResourceDictionary
{
    public DefaultTheme()
    {
        InitializeComponent();
    }
}
