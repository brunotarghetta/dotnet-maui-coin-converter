﻿namespace InvokePlatformCodeDemos;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
