﻿namespace Animations;

public partial class EasingsPage : ContentPage
{
    public EasingsPage()
    {
        InitializeComponent();
    }
}
