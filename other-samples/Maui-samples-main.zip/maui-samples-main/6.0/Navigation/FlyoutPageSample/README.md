---
name: .NET MAUI - FlyoutPage
description: "This sample demonstrates how to use a FlyoutPage and navigate between its pages of information (navigation)."
page_type: sample
languages:
- csharp
- xaml
products:
- dotnet-maui
- dotnet-core
urlFragment: navigation-flyoutpage
---
# FlyoutPage

This sample demonstrates how to use a `FlyoutPage` and navigate between its pages of information.

For more information about the sample see [FlyoutPage](https://docs.microsoft.com/dotnet/maui/user-interface/pages/flyoutpage).
