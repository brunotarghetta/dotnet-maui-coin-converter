---
name: .NET MAUI - Shell Tabs
description: "This sample demonstrates how to use Shell with tabs and navigate between its pages of information (navigation)."
page_type: sample
languages:
- csharp
- xaml
products:
- dotnet-maui
- dotnet-core
urlFragment: navigation-shelltabs
---
# Shell Tabs

This sample demonstrates how to use `Shell` with tabs and navigate between its pages of information.

For more information about the sample see [Shell Tabs](https://docs.microsoft.com/en-us/dotnet/maui/fundamentals/shell/tabs).
