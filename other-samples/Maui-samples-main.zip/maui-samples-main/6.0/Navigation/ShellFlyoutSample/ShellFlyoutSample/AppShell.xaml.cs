﻿namespace ShellFlyoutSample;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
    }
}
