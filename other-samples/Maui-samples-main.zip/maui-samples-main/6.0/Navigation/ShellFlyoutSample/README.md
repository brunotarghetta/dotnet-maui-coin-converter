---
name: .NET MAUI - Shell Flyout
description: "This sample demonstrates how to use Shell with a flyout and navigate between its pages of information (navigation)."
page_type: sample
languages:
- csharp
- xaml
products:
- dotnet-maui
- dotnet-core
urlFragment: navigation-shellflyout
---
# Shell Flyout

This sample demonstrates how to use `Shell` with a flyout and navigate between its pages of information.

For more information about the sample see [Shell Flyout](https://docs.microsoft.com/dotnet/maui/fundamentals/shell/flyout).
