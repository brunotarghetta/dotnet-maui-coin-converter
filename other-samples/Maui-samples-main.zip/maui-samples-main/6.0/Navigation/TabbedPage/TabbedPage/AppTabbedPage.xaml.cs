namespace TabbedPageSample;

public partial class AppTabbedPage
{
	public AppTabbedPage()
	{
		InitializeComponent();

		
	}
}